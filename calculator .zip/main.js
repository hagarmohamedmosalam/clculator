let output=document.getElementById("Clc")

function display(Num){
 output.value += Num; 
} 
function del(){
  output.value = "";
} 
function calcu(){
  output.value = eval(output.value);
} 